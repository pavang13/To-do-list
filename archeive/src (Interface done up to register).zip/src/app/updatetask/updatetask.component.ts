import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatetask',
  templateUrl: './updatetask.component.html',
  styleUrls: ['./updatetask.component.css']
})
export class UpdatetaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
